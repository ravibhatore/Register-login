
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const path = require("path");
const hbs =require("hbs");

const  staticPath =path.join(__dirname, "./public");
const template_path = path.join(__dirname,"./views/partials")
hbs.registerPartials(template_path);
app.set("view engine", "hbs");

async function connectdb() {
  mongoose.connect('mongodb://127.0.0.1:27017/my',
    {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
  console.log('Connected to MongoDB');
}
connectdb()

const userSchema = new mongoose.Schema
  ({
    name: String,
    email: String,
    password: String
  });

const item = mongoose.model('name', userSchema);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(staticPath));
app.use(express.static(template_path))
// app.use(express.static(partialsPath));
app.get('/register', (req, res) => {                                                                                                                        
  res.render('img');
});

app.post('/register', async (req, res) => {
  let { name, email,contact, password } = req.body;
  let saltRounds = 10;
  let salt = await bcrypt.genSalt(saltRounds);
  let hashedPassword = await bcrypt.hash(password, salt);
  console.log(hashedPassword);
  //
  let user = new item({ name, email,contact, password: hashedPassword });
  console.log(name);
  
  
  try {
    await user.save();
    res.send(`<h1>success</h1>`);
  }
  catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});




app.get('/login', (req, res) => {                                                                                                                        
  res.render('img');
});

app.post('/login', async (req, res) => {
  let { email, password } = req.body;
  try {
    let user = await item.findOne({ email });
    if (!user) {
      res.status(400).send('<h1>User not found</h1>');
      return;
    }
    let Match = await bcrypt.compare(password,user.password);
    console.log(password,"and",user.password);
    if (Match) {
      res.render("index.hbs")
    } else {
     res.send("invalid password")
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});
app.get('*',(req,res)=>{
  res.render("404")
})
const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Listening on port ${port}`));



